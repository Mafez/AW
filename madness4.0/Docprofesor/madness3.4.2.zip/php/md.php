<?php
session_start();
//echo "<link href='https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css' rel='stylesheet' />";
//echo "<script src='https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js'></script>";

include 'conexion.php';

$asunto = $_POST['asunto'];

$emisor = $_SESSION['id_usuario'];

$destinatario = $_POST['destinatario'];

$contenido = $_POST['contenido'];

$fecha = getdate();

$query = "SELECT usuario FROM usuarios WHERE usuarios.usuario = '$destinatario' ";


$result=mysqli_query($link,$query) or die('Could not look up user information; '.mysqli_error($link));
 
if(mysqli_num_rows($result)){
 
//echo "<script>swal('FUCK..','FUCK', 'error'); </script>";
    echo "<script>alert('JODER..'); </script>";
//include 'tildes.php';

$insertar = "INSERT INTO mensajes_directos (Asunto,Emisor,Destinatario,Contenido) VALUES ('$asunto','$emisor','$destinatario','$contenido')";
$retry_value = mysqli_query($link, $insertar) or die('Error: ' . mysqli_error($link));

header('Location: ../mandar_md.php');

}
 
else{
    echo "<script>alert('FUCK..'); </script>";
    //echo "<script>swal('Opss..','Debe proporcionar todos los campos solicitados. Por favor, inténtelo de nuevo.', 'error'); </script>";
}
mysqli_close($link);

?>